package pt.iade.juliadisconzi.bookly_server.models;

import jakarta.persistence.*;

@Entity
@Table(name = "compra")
public class Compra {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "compra_id")
    private int compraId;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    private Usuario usuario;

    @Column(name = "compra_estrela")
    private double compraEstrela;

    

    public int getCompraId() {
        return compraId;
    }

    public void setCompraId(int compraId) {
        this.compraId = compraId;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public double getCompraEstrela() {
        return compraEstrela;
    }

    public void setCompraEstrela(double compraEstrela) {
        this.compraEstrela = compraEstrela;
    }
}
