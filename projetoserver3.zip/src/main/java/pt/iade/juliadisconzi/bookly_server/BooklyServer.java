package pt.iade.juliadisconzi.bookly_server;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = )
public class BooklyServer {

	public static void main(String[] args) {
		SpringApplication.run(BooklyServer.class, args);
	}

}
