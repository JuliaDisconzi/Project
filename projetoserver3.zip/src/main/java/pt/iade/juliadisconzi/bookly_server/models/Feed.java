package pt.iade.juliadisconzi.bookly_server.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "feed") 
public class Feed {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name = "feed_id") 
    private int feedId;

    @ManyToOne
    @JoinColumn(name = "book_id")
    private Livro livro;

    @Column(name = "action_type") 
    private String actionType; 

    @Column(name = "timestamp") 
    private LocalDateTime timestamp; 

    

    public int getFeedId() {
        return feedId;
    }

    public void setFeedId(int feedId) {
        this.feedId = feedId;
    }

    public Livro getLivro() {
        return livro;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
