package pt.iade.juliadisconzi.bookly_server.models;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "usr") 
public class Usuario {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name = "user_id")
    private int userId;

    @Column(name = "username") 
    private String username;

    @Column(name = "email") 
    private String email;

    @Column(name = "password_hash") 
    private String passwordHash;

    @OneToMany(mappedBy = "usuario")
    private List<Anuncio> anuncios;

    @OneToMany(mappedBy = "usuario")
    private List<Compra> compras;

    @OneToMany(mappedBy = "usuarioAvaliado")
    private List<AvaliacaoUsuario> avaliacoesRecebidas;

    @OneToMany(mappedBy = "usuarioAvaliador")
    private List<AvaliacaoUsuario> avaliacoesFeitas;

    @OneToMany(mappedBy = "remetente")
    private List<Chat> mensagensEnviadas;

    @OneToMany(mappedBy = "destinatario")
    private List<Chat> mensagensRecebidas;

    @OneToMany(mappedBy = "usuario")
    private List<Feed> atividades;

    @OneToMany(mappedBy = "usuario")
    private List<Livro> livros;

    @OneToOne(mappedBy = "usuario")
    private UserSettings userSettings;

    

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public List<Anuncio> getAnuncios() {
        return anuncios;
    }

    public void setAnuncios(List<Anuncio> anuncios) {
        this.anuncios = anuncios;
    }

    public List<Compra> getCompras() {
        return compras;
    }

    public void setCompras(List<Compra> compras) {
        this.compras = compras;
    }

}
