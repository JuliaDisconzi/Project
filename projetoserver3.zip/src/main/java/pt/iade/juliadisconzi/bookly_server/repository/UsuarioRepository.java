package pt.iade.juliadisconzi.bookly_server.repository;

public class UsuarioRepository {

}
