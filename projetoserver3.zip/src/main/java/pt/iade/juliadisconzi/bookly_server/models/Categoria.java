package pt.iade.juliadisconzi.bookly_server.models;

import jakarta.persistence.*;

@Entity
@Table(name = "categoria") 
public class Categoria {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name = "catg_id") 
    private int catgId;

    @Column(name = "catg_temas") 
    private String catgTemas;

    

    @OneToOne(mappedBy = "categoria")
    private Book book;

    @OneToMany(mappedBy = "categoria")
    private List<Anuncio> anuncios;

    

    public int getCatgId() {
        return catgId;
    }

    public void setCatgId(int catgId) {
        this.catgId = catgId;
    }

    public String getCatgTemas() {
        return catgTemas;
    }

    public void setCatgTemas(String catgTemas) {
        this.catgTemas = catgTemas;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public List<Anuncio> getAnuncios() {
        return anuncios;
    }

    public void setAnuncios(List<Anuncio> anuncios) {
        this.anuncios = anuncios;
    }
}
