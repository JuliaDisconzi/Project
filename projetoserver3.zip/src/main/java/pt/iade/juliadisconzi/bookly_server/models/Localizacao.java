package pt.iade.juliadisconzi.bookly_server.models;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "localizacao") 
public class Localizacao {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name = "loc_id") 
    private int locId;

    @Column(name = "loc_concelhos") 
    private String locConcelhos; 

  
    @OneToMany(mappedBy = "localizacao")
    private List<Anuncio> anuncios;

    
    @OneToMany(mappedBy = "localizacao")
    private List<Compra> compras;

    

    public int getLocId() {
        return locId;
    }

    public void setLocId(int locId) {
        this.locId = locId;
    }

    public String getLocConcelhos() {
        return locConcelhos;
    }

    public void setLocConcelhos(String locConcelhos) {
        this.locConcelhos = locConcelhos;
    }

    

    public List<Anuncio> getAnuncios() {
        return anuncios;
    }

    public void setAnuncios(List<Anuncio> anuncios) {
        this.anuncios = anuncios;
    }

    public List<Compra> getCompras() {
        return compras;
    }

    public void setCompras(List<Compra> compras) {
        this.compras = compras;
    }
}
