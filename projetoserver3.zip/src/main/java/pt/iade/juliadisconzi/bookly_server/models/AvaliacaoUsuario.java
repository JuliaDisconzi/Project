package pt.iade.juliadisconzi.bookly_server.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "avaliacao_usuario") 
public class AvaliacaoUsuario {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name = "id_avaliacao") 
    private int idAvaliacao;

    @Column(name = "id_usuario_avaliado") 
    private int idUsuarioAvaliado;

    @Column(name = "id_usuario_avaliador") 
    private int idUsuarioAvaliador;

    @Column(name = "id_livro") 
    private int idLivro;

    @Column(name = "classificacao") 
    private int classificacao; 

    @Column(name = "comentario", columnDefinition = "text")
    private String comentario; 

    @Column(name = "data_avaliacao") 
    private LocalDateTime dataAvaliacao; 

    
    @ManyToOne
    @JoinColumn(name = "id_usuario_avaliado", referencedColumnName = "user_id", insertable = false, updatable = false)
    private Usr usuarioAvaliado;

    @ManyToOne
    @JoinColumn(name = "id_usuario_avaliador", referencedColumnName = "user_id", insertable = false, updatable = false)
    private Usr usuarioAvaliador;

    @ManyToOne
    @JoinColumn(name = "id_livro", referencedColumnName = "book_id", insertable = false, updatable = false)
    private Book livro;

   

    public int getIdAvaliacao() {
        return idAvaliacao;
    }

    public void setIdAvaliacao(int idAvaliacao) {
        this.idAvaliacao = idAvaliacao;
    }

  

    public Usr getUsuarioAvaliado() {
        return usuarioAvaliado;
    }

    public void setUsuarioAvaliado(Usr usuarioAvaliado) {
        this.usuarioAvaliado = usuarioAvaliado;
    }

    public Usr getUsuarioAvaliador() {
        return usuarioAvaliador;
    }

    public void setUsuarioAvaliador(Usr usuarioAvaliador) {
        this.usuarioAvaliador = usuarioAvaliador;
    }

    public Book getLivro() {
        return livro;
    }

    public void setLivro(Book livro) {
        this.livro = livro;
    }
}
