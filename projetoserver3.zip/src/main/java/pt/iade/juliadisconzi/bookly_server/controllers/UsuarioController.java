package pt.iade.juliadisconzi.bookly_server.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pt.iade.juliadisconzi.bookly_server.models.Usuario;
import pt.iade.juliadisconzi.bookly_server.repositories.UsuarioRepository;

import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("")
    public List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll();
    }

    @GetMapping("/{id}")
    public Usuario buscarUsuarioPorId(@PathVariable int id) {
        return usuarioRepository.findById(id);
    }

    @PostMapping("/criar")
    public Usuario criarUsuario(@RequestBody Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    @PutMapping("/{id}/atualizar")
    public Usuario atualizarUsuario(@PathVariable int id, @RequestBody Usuario novoUsuario) {
        Usuario usuario = usuarioRepository.findById(id);
        if (usuario != null) {
            // Atualiza os campos do usuário com os dados do novoUsuario
            // Implemente a lógica necessária para atualizar os campos aqui
            usuario.setUsername(novoUsuario.getUsername());
            usuario.setEmail(novoUsuario.getEmail());
            usuario.setPasswordHash(novoUsuario.getPasswordHash());
            // ... Outros campos que precisam ser atualizados
            return usuarioRepository.save(usuario);
        } else {
            return null; // Ou lançar uma exceção indicando que o usuário não foi encontrado
        }
    }

    @DeleteMapping("/{id}/excluir")
    public void excluirUsuario(@PathVariable int id) {
        usuarioRepository.deleteById(id);
    }
}
