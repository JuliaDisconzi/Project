package pt.iade.juliadisconzi.bookly_server.models;

import jakarta.persistence.*;

@Entity
@Table(name = "anuncio") 
public class Anuncio {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    @Column(name = "id_anu") 
    private int idAnuncio;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    private Usr usr; 

    @Column(name = "title") 
    private String title; 

    @Column(name = "author") 
    private String author; 

    @Column(name = "category")
    private String category; 

    @Column(name = "condit") 
    private String condition; 

    @Column(name = "price") 
    private double price;

    @Column(name = "descr") 
    private String description; 

    @Column(name = "numbr") 
    private double number; 

    @ManyToOne
    @JoinColumn(name = "loc_id", referencedColumnName = "loc_id")
    private Localizacao localizacao;

    

    public int getIdAnuncio() {
        return idAnuncio;
    }

    public void setIdAnuncio(int idAnuncio) {
        this.idAnuncio = idAnuncio;
    }

    public Usr getUsr() {
        return usr;
    }

    public void setUsr(Usr usr) {
        this.usr = usr;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getNumber() {
        return number;
    }

    public void setNumber(double number) {
        this.number = number;
    }

    public Localizacao getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(Localizacao localizacao) {
        this.localizacao = localizacao;
    }
}
