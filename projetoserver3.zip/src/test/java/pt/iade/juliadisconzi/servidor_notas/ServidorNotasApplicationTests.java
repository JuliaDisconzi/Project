package pt.iade.juliadisconzi.servidor_notas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorNotasApplicationTests {

	@Test
	void contextLoads() {
	}

}
