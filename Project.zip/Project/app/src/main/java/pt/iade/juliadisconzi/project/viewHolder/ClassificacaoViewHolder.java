package pt.iade.juliadisconzi.project.viewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import pt.iade.juliadisconzi.project.R;
import pt.iade.juliadisconzi.project.model.Classificacao;

public class ClassificacaoViewHolder extends RecyclerView.ViewHolder {

    private TextView nomeUsuario;
    private RatingBar estrelasClassificacao;
    private ImageView fotoAvaliacao;

    public ClassificacaoViewHolder(@NonNull View itemView) {
        super(itemView);
        nomeUsuario = itemView.findViewById(R.id.nome_usuario);
        estrelasClassificacao = itemView.findViewById(R.id.estrelas_classificacao);
        fotoAvaliacao = itemView.findViewById(R.id.foto_avaliacao);
    }

    public void bindData(Classificacao classificacao) {
        nomeUsuario.setText(classificacao.getNomeUsuario());
        estrelasClassificacao.setRating(Float.parseFloat(classificacao.getAvaliacao()));
        fotoAvaliacao.setImageResource(classificacao.getFotoAvaliacao());
    }
}
