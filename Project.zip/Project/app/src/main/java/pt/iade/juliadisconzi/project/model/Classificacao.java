package pt.iade.juliadisconzi.project.model;

import java.util.ArrayList;

public class Classificacao {

    private int id;
    private String avaliacao;

    public Classificacao(int id, String avaliacao){
        this.id = id;
        this.avaliacao = avaliacao;
    }

    public static ArrayList<Classificacao>List(){
        ArrayList<Classificacao> listaclassificacao = new ArrayList<>();

        for (int i = 0; i < 100; i++) {
            listaclassificacao.add(new Classificacao(i, String.valueOf(i)));
        }
        return listaclassificacao;
    }

    public int intgetId(){return id;}

    public void setId(int id){this.id=id;}

    public String getAvaliacao(){return avaliacao;}

    public void setAvaliacao(String avaliacao){ this.avaliacao = avaliacao;}

    public int getModelo(){ return 0;}


    public int getNomeUsuario() {
        return 0;
    }

    public int getFotoAvaliacao() {
        return 0;
    }
}