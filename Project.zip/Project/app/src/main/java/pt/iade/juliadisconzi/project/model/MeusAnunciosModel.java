package pt.iade.juliadisconzi.project.model;

public class MeusAnunciosModel {
    private String titulo;
    private String preco;
    private String imagePath;

    public MeusAnunciosModel(String titulo, String preco, String imagePath) {
        this.titulo = titulo;
        this.preco = preco;
        this.imagePath = imagePath;
    }

    public MeusAnunciosModel() {

    }

    public String getTitulo() {
        return titulo;
    }

    public String getPreco() {
        return preco;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}
