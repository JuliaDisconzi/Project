package pt.iade.juliadisconzi.project.model;

public class Livros {

    private int bookID;
    private String title;
    private String author;
    private String category;
    private String condition;
    private double price;
    private int userID;

    public Livros(int bookID, String title, String author, String category, String condition, double price, int userID) {
        this.bookID = bookID;
        this.title = title;
        this.author = author;
        this.category = category;
        this.condition = condition;
        this.price = price;
        this.userID = userID;
    }

    public int getBookID() {
        return bookID;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getCategory() {
        return category;
    }

    public String getCondition() {
        return condition;
    }

    public double getPrice() {
        return price;
    }

    public int getUserID() {
        return userID;
    }
}
