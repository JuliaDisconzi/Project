package pt.iade.juliadisconzi.project.model;

public class Usuarios {

    private int userID;

    private String userNome;

    private String email;


    private String password;

    public Usuarios(String userNome, String email, String password, int userID) {
        this.userID = userID;
        this.userNome = userNome;
        this.email = email;
        this.password = password;
    }

    public int getUserID() {
        return userID;
    }

    public String getUserNome() {
        return userNome;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}


