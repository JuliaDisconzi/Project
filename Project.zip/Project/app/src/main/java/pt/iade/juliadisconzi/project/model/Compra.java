package pt.iade.juliadisconzi.project.model;

public class Compra {

    private int compraID;
    private int userID;
    private int compraEstrela;

    public Compra(int compraID, int userID, int compraEstrela) {
        this.compraID = compraID;
        this.userID = userID;
        this.compraEstrela = compraEstrela;
    }

    public int getCompraID() {
        return compraID;
    }

    public int getUserID() {
        return userID;
    }

    public int getCompraEstrela() {
        return compraEstrela;
    }
}
