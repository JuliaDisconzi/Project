package pt.iade.juliadisconzi.project.viewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import pt.iade.juliadisconzi.project.R;

public class MeusAnunciosViewHolder extends RecyclerView.ViewHolder {
    public ImageView imagem;
    public TextView titulo;
    public TextView preco;

    public MeusAnunciosViewHolder(@NonNull View itemView) {
        super(itemView);
        imagem = itemView.findViewById(R.id.livro);
        titulo = itemView.findViewById(R.id.lista_anuncio);
        preco = itemView.findViewById(R.id.preco);
    }
}
