package pt.iade.juliadisconzi.project.model;

import java.time.LocalDateTime;

public class Mensagens {

    private int chatID;
    private int senderID;
    private int receiverID;
    private String messageText;
    private LocalDateTime timestamp;

    public Mensagens(int chatID, int senderID, int receiverID, String messageText, LocalDateTime timestamp) {
        this.chatID = chatID;
        this.senderID = senderID;
        this.receiverID = receiverID;
        this.messageText = messageText;
        this.timestamp = timestamp;
    }

    public int getChatID() {
        return chatID;
    }

    public int getSenderID() {
        return senderID;
    }

    public int getReceiverID() {
        return receiverID;
    }

    public String getMessageText() {
        return messageText;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}
