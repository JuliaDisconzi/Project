package pt.iade.juliadisconzi.project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FormCategorias extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_categorias);
    }
}

