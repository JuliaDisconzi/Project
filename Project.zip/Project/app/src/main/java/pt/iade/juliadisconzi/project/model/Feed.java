package pt.iade.juliadisconzi.project.model;

import java.time.LocalDateTime;

public class Feed {

    private int feedID;
    private int bookID;
    private String actionType;
    private LocalDateTime timestamp;

    public Feed(int feedID, int bookID, String actionType, LocalDateTime timestamp) {
        this.feedID = feedID;
        this.bookID = bookID;
        this.actionType = actionType;
        this.timestamp = timestamp;
    }

    public int getFeedID() {
        return feedID;
    }

    public int getBookID() {
        return bookID;
    }

    public String getActionType() {
        return actionType;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}
