package pt.iade.juliadisconzi.project.model;

import java.time.LocalDateTime;

public class AvaliacaoUsuario {

    private int idAvaliacao;
    private int idUsuarioAvaliado;
    private int idUsuarioAvaliador;
    private int idLivro;
    private int classificacao;
    private String comentario;
    private LocalDateTime dataAvaliacao;

    public AvaliacaoUsuario(int idAvaliacao, int idUsuarioAvaliado, int idUsuarioAvaliador, int idLivro,
                            int classificacao, String comentario, LocalDateTime dataAvaliacao) {
        this.idAvaliacao = idAvaliacao;
        this.idUsuarioAvaliado = idUsuarioAvaliado;
        this.idUsuarioAvaliador = idUsuarioAvaliador;
        this.idLivro = idLivro;
        this.classificacao = classificacao;
        this.comentario = comentario;
        this.dataAvaliacao = dataAvaliacao;
    }

    public int getIdAvaliacao() {
        return idAvaliacao;
    }

    public int getIdUsuarioAvaliado() {
        return idUsuarioAvaliado;
    }

    public int getIdUsuarioAvaliador() {
        return idUsuarioAvaliador;
    }

    public int getIdLivro() {
        return idLivro;
    }

    public int getClassificacao() {
        return classificacao;
    }

    public String getComentario() {
        return comentario;
    }

    public LocalDateTime getDataAvaliacao() {
        return dataAvaliacao;
    }
}
