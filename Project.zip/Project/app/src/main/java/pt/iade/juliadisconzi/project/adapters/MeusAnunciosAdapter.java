
package pt.iade.juliadisconzi.project.adapters;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import pt.iade.juliadisconzi.project.R;
import pt.iade.juliadisconzi.project.model.MeusAnunciosModel;

public class MeusAnunciosAdapter extends RecyclerView.Adapter<MeusAnunciosAdapter.MeusAnunciosViewHolder> {

    private List<MeusAnunciosModel> anunciosList;
    private Context context;
    private OnAnuncioClickListener listener;

    public MeusAnunciosAdapter(Context context, List<MeusAnunciosModel> anunciosList) {
        this.context = context;
        this.anunciosList = anunciosList;
    }

    @NonNull
    @Override
    public MeusAnunciosViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_meus_anuncios, parent, false);
        return new MeusAnunciosViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MeusAnunciosViewHolder holder, int position) {
        MeusAnunciosModel anuncio = anunciosList.get(position);

        holder.titulo.setText(anuncio.getTitulo());
        holder.preco.setText(anuncio.getPreco());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onAnuncioClick(anuncio);
            }
        });
    }

    @Override
    public int getItemCount() {
        return anunciosList.size();
    }

    public void setOnAnuncioClickListener(OnAnuncioClickListener listener) {
        this.listener = listener;
    }

    public interface OnAnuncioClickListener {
        void onAnuncioClick(MeusAnunciosModel anuncio);
    }

    public static class MeusAnunciosViewHolder extends RecyclerView.ViewHolder {
        ImageView imagem;
        TextView titulo, preco;

        public MeusAnunciosViewHolder(@NonNull View itemView) {
            super(itemView);
            imagem = itemView.findViewById(R.id.livro);
            titulo = itemView.findViewById(R.id.lista_anuncio);
            preco = itemView.findViewById(R.id.preco);
        }
    }
}
