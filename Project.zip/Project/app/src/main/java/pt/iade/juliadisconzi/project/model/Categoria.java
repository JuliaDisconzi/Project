package pt.iade.juliadisconzi.project.model;

public class Categoria {

    private int catgID;
    private String catgTemas;

    public Categoria(int catgID, String catgTemas) {
        this.catgID = catgID;
        this.catgTemas = catgTemas;
    }

    public int getCatgID() {
        return catgID;
    }

    public String getCatgTemas() {
        return catgTemas;
    }
}
