package pt.iade.juliadisconzi.project.viewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import pt.iade.juliadisconzi.project.R;
import pt.iade.juliadisconzi.project.model.Anuncio;

public class AnuncioViewHolder extends RecyclerView.ViewHolder {

    private ImageView livro;

    private TextView preco;

    private TextView lista_anuncio;
    public AnuncioViewHolder(@NonNull View itemView) {
        super(itemView);
        lista_anuncio = itemView.findViewById(R.id.lista_anuncio);
        livro = itemView.findViewById(R.id.livro);
        preco = itemView.findViewById(R.id.preco);

    }

    public void bindData(Anuncio anuncio) {
        lista_anuncio.setText(anuncio.getDescricao());
        preco.setText(anuncio.getPreco());
        livro.setImageDrawable(anuncio.getImagem());


       }
}
